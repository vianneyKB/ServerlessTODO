
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vianneykb',
  applicationName: 'serverless-todo-app',
  appUid: 'Yy3Vs1LxJdbwBnjWrx',
  orgUid: 'cdef21fd-3858-4eed-9612-b43a3aad7712',
  deploymentUid: '4e66cbfd-f15b-4ae3-95c7-c0f3d047c8d6',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-DeleteTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deleteTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}